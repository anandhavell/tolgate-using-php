<div class="user-profile" >
                        
                        
                        <ul style="list-style-type: none">
                           
                           <li  class="active"><a href="all-classifieds.php">Home</a></li>
                           <li  class="active"><a href="add-tolgate-place.php">Add Places</a></li>
                           <li  class="active"><a href="list-tolgate-place.php">Mange Tollgate Places</a></li>
                           <li  class="active"><a href="overall-user.php">Over all User</a></li>
                           <li  class="active"><a href="payment-status.php">Tollgate Travelled History</a></li>
                           
                        </ul>
                     </div>