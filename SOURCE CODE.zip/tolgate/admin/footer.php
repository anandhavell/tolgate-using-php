<footer>
			
			<div class="agileits-footer-bottom text-center">
			<div class="container">
			
				<div class="copyrights">
					<p> © 2018 Design by  <a href="http://realtimeproject.in/"> DLK Technologies</a></p>
				</div>
				<div class="clearfix"></div>
			</div>
		</div>
		</footer>



		<style type="text/css">
			footer{
			position: fixed;
    		bottom: 0px;
			}
		</style>