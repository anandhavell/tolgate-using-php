<header>
		<div class="w3ls-header"><!--header-one--> 
			
			<div class="w3ls-header-right">
				<ul class="border-none">
					<li class="dropdown head-dpdn">
						<a aria-expanded="false"><i class="fa fa-user" aria-hidden="true"></i><?php  echo $row['username'];  ?></a>
					</li>
					<li class="dropdown head-dpdn">
						<a href="index.php" aria-expanded="false">Sign Out</a>
					</li>
				</ul>
			</div>
			
			<div class="clearfix"> </div> 
		</div>

	</header>


	<style type="text/css">
		.border-none{
			border: none;
		}
	</style>